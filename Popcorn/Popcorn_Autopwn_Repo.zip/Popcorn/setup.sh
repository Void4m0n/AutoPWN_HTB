#!/bin/bash

sudo apt-get install sshpass -y

pip3 install -r requirements.txt

