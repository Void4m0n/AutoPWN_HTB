#!/bin/bash

sudo apt-get install tar gzip sshpass bzip2 -y

pip3 install -r requirements.txt

